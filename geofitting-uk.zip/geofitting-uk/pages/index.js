import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { ChevronRight, ChevronLeft, Check, User, Briefcase, GraduationCap, Building2, Languages, DollarSign, Users, Target, MapPin, Clock, FileText, Star, AlertCircle, TrendingUp, Calendar, Globe, Award, ChevronDown, ChevronUp, Info, Plane, Home, BookOpen, Heart, Loader2, CheckCircle2, Mail, Database } from 'lucide-react';
import { initEmailJS, submitQuestionnaireData } from '../lib/integrations';

export default function Geofitting() {
  const [currentSection, setCurrentSection] = useState(0);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [expandedRoute, setExpandedRoute] = useState(null);
  const [expandedCountry, setExpandedCountry] = useState(0);
  const [activeTab, setActiveTab] = useState('resumo');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionStatus, setSubmissionStatus] = useState(null);
  const [formData, setFormData] = useState({
    // Seção 1: Dados Pessoais
    nomeCompleto: '',
    email: '',
    telefone: '',
    faixaEtaria: '',
    cidadeAtual: '',
    estadoCivil: '',
    nacionalidade: '',
    possuiDuplaCidadania: '',
    
    // Seção 2: Perfil Profissional
    areaAtuacao: '',
    subAreaTech: '',
    nivelCargo: '',
    tipoContrato: '',
    setorEmpresa: '',
    porteEmpresa: '',
    anosExperiencia: '',
    tempoEmpresaAtual: '',
    gestaoEquipe: '',
    trabalhoRemoto: '',
    
    // Seção 3: Realizações
    possuiPremios: '',
    tipoPremios: [],
    possuiPublicacoes: '',
    tipoPublicacoes: [],
    possuiPatentes: '',
    possuiPalestras: '',
    nivelPalestras: [],
    aparicoesMidia: '',
    tipoMidia: [],
    membroAssociacao: '',
    contribuicoesOpenSource: '',
    mentoria: '',
    
    // Seção 4: Formação Acadêmica
    nivelFormacao: '',
    areaCurso: '',
    tipoInstituicao: '',
    posGraduacao: '',
    instituicaoPosReconhecida: '',
    certificacoes: [],
    
    // Seção 5: Situação Empresarial
    possuiEmpresa: '',
    setorEmpresaPropria: '',
    faturamentoAnual: '',
    numeroFuncionarios: '',
    tempoEmpresaAberta: '',
    atuacaoInternacional: '',
    interesseEmpreenderExterior: '',
    tipoNegocioExterior: '',
    
    // Seção 6: Idiomas
    nivelIngles: '',
    certificacaoIngles: '',
    nivelEspanhol: '',
    nivelFrances: '',
    nivelAlemao: '',
    nivelItaliano: '',
    outroIdioma: '',
    disposicaoAprender: '',
    
    // Seção 7: Capacidade Financeira
    rendaMensalFamiliar: '',
    fonteRendaPrincipal: '',
    estabilidadeRenda: '',
    patrimonioLiquido: '',
    tipoPatrimonio: [],
    capacidadeInvestimento: '',
    reservaEmergencia: '',
    dividasSignificativas: '',
    disposicaoGoldenVisa: '',
    
    // Seção 8: Composição Familiar
    situacaoConjuge: '',
    areaConjuge: '',
    nivelInglesConjuge: '',
    flexibilidadeConjuge: '',
    numeroFilhos: '',
    faixaEtariaFilhos: [],
    tipoEscolaAtual: '',
    necessidadesEspeciais: '',
    outrosDependentes: '',
    
    // Seção 9: Objetivos de Vida
    motivacaoPrincipal: [],
    objetivoCarreira: '',
    expectativaSalarial: '',
    prioridadeVidaTrabalho: '',
    planoRetorno: '',
    horizonteTempo: '',
    objetivoEducacaoFilhos: '',
    planoAposentadoria: '',
    
    // Seção 10: Preferências de Destino
    paisesInteresse: [],
    paisesDescartados: [],
    preferenciaRegiao: '',
    preferenciaClima: '',
    preferenciaTamanhoCidade: '',
    importanciaComunidadeBR: '',
    preferenciaIdiomaPais: '',
    importanciaProximidadeBR: '',
    preferenciaEstiloVida: '',
    toleranciaCustoVida: '',
    prioridadeSeguranca: '',
    
    // Seção 11: Timeline e Urgência
    prazoIdeal: '',
    flexibilidadePrazo: '',
    situacaoAtualBrasil: '',
    fatoresUrgencia: [],
    disponibilidadeViagem: '',
    disponibilidadeMudanca: '',
    jaIniciouProcesso: '',
    processoAnterior: '',
    conhecimentoRotas: '',
    rotasConhecidas: [],
    disposicaoInvestirTempo: '',
    disposicaoInvestirDinheiro: ''
  });

  // Inicializar EmailJS
  useEffect(() => {
    initEmailJS();
  }, []);

  // Dados completos dos países e rotas
  const countryData = {
    portugal: {
      nome: 'Portugal',
      bandeira: '🇵🇹',
      capital: 'Lisboa',
      idioma: 'Português',
      custoVida: 'Médio',
      qualidadeVida: '9/10',
      seguranca: '9/10',
      clima: 'Mediterrâneo',
      comunidadeBR: 'Muito grande (300k+)',
      tempoResidencia: '5 anos para cidadania',
      rotas: {
        techVisa: {
          nome: 'Tech Visa',
          tipo: 'Trabalho qualificado',
          descricao: 'Visto para profissionais de tecnologia com proposta de trabalho em empresa certificada pelo IAPMEI.',
          requisitos: ['Proposta de trabalho de empresa certificada', 'Formação superior em área de TI ou 5+ anos experiência', 'Contrato com salário mínimo de €1.500/mês', 'Seguro saúde'],
          timeline: '2-4 meses',
          custoEstimado: '€500-1.500',
          taxaSucesso: '85%',
          vantagens: ['Processo simplificado', 'Família incluída', 'Caminho para cidadania'],
          desvantagens: ['Depende de proposta de emprego', 'Restrito a empresas certificadas']
        },
        d7: {
          nome: 'D7 - Visto de Rendimentos',
          tipo: 'Renda passiva',
          descricao: 'Visto para pessoas com renda passiva comprovada.',
          requisitos: ['Renda passiva mínima de €760/mês', 'Comprovação de origem lícita', 'Alojamento em Portugal', 'Seguro saúde'],
          timeline: '3-6 meses',
          custoEstimado: '€1.000-3.000',
          taxaSucesso: '80%',
          vantagens: ['Não precisa de emprego', 'Pode trabalhar em PT', 'Família incluída'],
          desvantagens: ['Precisa comprovar renda recorrente', 'Exige presença física']
        },
        d8: {
          nome: 'D8 - Nômade Digital',
          tipo: 'Trabalho remoto',
          descricao: 'Visto para trabalhadores remotos com empresas estrangeiras.',
          requisitos: ['Contrato remoto com empresa estrangeira', 'Renda mínima de €3.040/mês', 'Seguro saúde internacional', 'Comprovante de alojamento'],
          timeline: '2-4 meses',
          custoEstimado: '€1.000-2.000',
          taxaSucesso: '82%',
          vantagens: ['Mantém emprego atual', 'Processo rápido', 'Pode levar família'],
          desvantagens: ['Renda mínima alta', 'Precisa vínculo com empresa estrangeira']
        },
        goldenVisa: {
          nome: 'Golden Visa',
          tipo: 'Investimento',
          descricao: 'Autorização de residência através de investimento qualificado.',
          requisitos: ['Investimento mínimo de €500.000 em fundos', 'Ou €500.000 em pesquisa científica', 'Manutenção por 5 anos'],
          timeline: '6-12 meses',
          custoEstimado: '€500.000+',
          taxaSucesso: '95%',
          vantagens: ['Não exige residência contínua', 'Caminho rápido para cidadania', 'Acesso a toda UE'],
          desvantagens: ['Alto investimento', 'Imóveis não qualificam mais em Lisboa/Porto']
        }
      },
      cidades: ['Lisboa', 'Porto', 'Braga', 'Coimbra', 'Cascais', 'Setúbal']
    },
    alemanha: {
      nome: 'Alemanha',
      bandeira: '🇩🇪',
      capital: 'Berlim',
      idioma: 'Alemão',
      custoVida: 'Médio-Alto',
      qualidadeVida: '9/10',
      seguranca: '8/10',
      clima: 'Temperado',
      comunidadeBR: 'Grande (150k+)',
      tempoResidencia: '8 anos para cidadania (pode reduzir para 6)',
      rotas: {
        blueCard: {
          nome: 'EU Blue Card',
          tipo: 'Trabalho qualificado',
          descricao: 'Visto para profissionais altamente qualificados.',
          requisitos: ['Diploma universitário reconhecido', 'Salário mínimo de €45.300/ano', 'Para áreas de escassez (TI): €41.000/ano', 'Contrato de pelo menos 1 ano'],
          timeline: '2-4 meses',
          custoEstimado: '€100-500',
          taxaSucesso: '90%',
          vantagens: ['Família incluída', 'Mobilidade na UE após 18 meses', 'Residência permanente em 21-33 meses'],
          desvantagens: ['Exige diploma reconhecido', 'Precisa proposta de emprego']
        },
        chancenkarte: {
          nome: 'Chancenkarte (Opportunity Card)',
          tipo: 'Sistema de pontos',
          descricao: 'Visto baseado em pontos para buscar trabalho.',
          requisitos: ['Mínimo 6 pontos no sistema', 'Pontos por: idade, idioma, experiência', 'Diploma ou qualificação profissional', 'Recursos para se manter'],
          timeline: '2-4 meses',
          custoEstimado: '€75-200',
          taxaSucesso: '75%',
          vantagens: ['Mais flexível', 'Pode trabalhar 20h/semana', 'Válido por 1 ano'],
          desvantagens: ['Novo programa', 'Sistema de pontos complexo']
        }
      },
      cidades: ['Berlim', 'Munique', 'Frankfurt', 'Hamburgo', 'Colônia', 'Stuttgart']
    },
    eua: {
      nome: 'Estados Unidos',
      bandeira: '🇺🇸',
      capital: 'Washington D.C.',
      idioma: 'Inglês',
      custoVida: 'Alto',
      qualidadeVida: '8/10',
      seguranca: '7/10',
      clima: 'Variado',
      comunidadeBR: 'Muito grande (2M+)',
      tempoResidencia: '5 anos para cidadania',
      rotas: {
        eb2Niw: {
          nome: 'EB-2 NIW',
          tipo: 'Green Card direto',
          descricao: 'Green Card para profissionais cujo trabalho beneficia os EUA.',
          requisitos: ['Mestrado ou bacharelado + 5 anos experiência', 'Demonstrar benefício ao interesse nacional', 'Evidências de realizações excepcionais'],
          timeline: '12-24 meses',
          custoEstimado: '$15.000-25.000',
          taxaSucesso: '70%',
          vantagens: ['Não precisa empregador sponsor', 'Green Card direto', 'Família incluída'],
          desvantagens: ['Processo complexo', 'Requer evidências robustas', 'Tempo de espera longo']
        },
        eb1a: {
          nome: 'EB-1A',
          tipo: 'Green Card direto',
          descricao: 'Green Card para indivíduos com habilidades extraordinárias.',
          requisitos: ['Prêmios nacionais/internacionais', 'Atender 3 de 10 critérios', 'Reconhecimento como top da área'],
          timeline: '8-18 meses',
          custoEstimado: '$15.000-30.000',
          taxaSucesso: '60%',
          vantagens: ['Processo mais rápido', 'Não precisa empregador', 'Premium processing disponível'],
          desvantagens: ['Critérios muito exigentes', 'Alto padrão de evidências']
        },
        o1a: {
          nome: 'O-1A',
          tipo: 'Visto temporário',
          descricao: 'Visto para indivíduos com habilidades extraordinárias.',
          requisitos: ['Atender 3 de 8 critérios', 'Prêmios, publicações, salário alto', 'Proposta de trabalho ou agente nos EUA'],
          timeline: '3-6 meses',
          custoEstimado: '$8.000-15.000',
          taxaSucesso: '75%',
          vantagens: ['Mais rápido que EB-1A', 'Pode renovar indefinidamente', 'Cônjuge pode trabalhar'],
          desvantagens: ['Temporário', 'Vinculado ao empregador/agente']
        },
        l1a: {
          nome: 'L-1A',
          tipo: 'Transferência executiva',
          descricao: 'Visto para executivos transferidos de multinacional.',
          requisitos: ['1+ ano na empresa no exterior', 'Cargo executivo ou gerencial', 'Empresa com operação nos EUA'],
          timeline: '3-6 meses',
          custoEstimado: '$10.000-20.000',
          taxaSucesso: '80%',
          vantagens: ['Caminho para Green Card (EB-1C)', 'Cônjuge pode trabalhar', 'Sem limite de vistos'],
          desvantagens: ['Restrito a multinacionais', 'Precisa cargo gerencial real']
        }
      },
      cidades: ['Nova York', 'San Francisco', 'Austin', 'Miami', 'Los Angeles', 'Boston', 'Seattle']
    },
    espanha: {
      nome: 'Espanha',
      bandeira: '🇪🇸',
      capital: 'Madri',
      idioma: 'Espanhol',
      custoVida: 'Médio',
      qualidadeVida: '9/10',
      seguranca: '9/10',
      clima: 'Mediterrâneo',
      comunidadeBR: 'Grande (200k+)',
      tempoResidencia: '2 anos para cidadania (brasileiros)',
      rotas: {
        nomadaDigital: {
          nome: 'Visa Nómada Digital',
          tipo: 'Trabalho remoto',
          descricao: 'Visto para trabalhadores remotos com clientes internacionais.',
          requisitos: ['Trabalho remoto para empresa estrangeira', 'Renda mínima de €2.520/mês', '3+ anos de experiência', 'Seguro saúde'],
          timeline: '2-4 meses',
          custoEstimado: '€500-1.500',
          taxaSucesso: '80%',
          vantagens: ['Mantém trabalho atual', 'Válido por 3 anos', 'Regime fiscal especial'],
          desvantagens: ['Máximo 20% clientes espanhóis', 'Renda mínima considerável']
        },
        altamenteQualificado: {
          nome: 'Visa Altamente Qualificado',
          tipo: 'Trabalho qualificado',
          descricao: 'Visto para profissionais com alta qualificação.',
          requisitos: ['Diploma universitário ou 3+ anos experiência', 'Salário mínimo de €40.000/ano', 'Empresa cadastrada no UGE'],
          timeline: '1-3 meses',
          custoEstimado: '€500-1.000',
          taxaSucesso: '85%',
          vantagens: ['Processo rápido', 'Família incluída', 'Caminho para residência'],
          desvantagens: ['Restrito a empresas grandes', 'Vinculado ao empregador']
        }
      },
      cidades: ['Madri', 'Barcelona', 'Valência', 'Sevilha', 'Málaga', 'Bilbao']
    },
    holanda: {
      nome: 'Holanda',
      bandeira: '🇳🇱',
      capital: 'Amsterdã',
      idioma: 'Holandês (inglês amplamente falado)',
      custoVida: 'Alto',
      qualidadeVida: '9/10',
      seguranca: '9/10',
      clima: 'Temperado oceânico',
      comunidadeBR: 'Média (50k+)',
      tempoResidencia: '5 anos para cidadania',
      rotas: {
        kennismigrant: {
          nome: 'Highly Skilled Migrant',
          tipo: 'Trabalho qualificado',
          descricao: 'Visto para profissionais qualificados.',
          requisitos: ['Proposta de empresa reconhecida (IND sponsor)', 'Salário mínimo de €4.752/mês (ou €3.549 se <30 anos)', 'Contrato de trabalho'],
          timeline: '2-4 semanas',
          custoEstimado: '€320-1.000',
          taxaSucesso: '95%',
          vantagens: ['Processo muito rápido', 'Cônjuge pode trabalhar', '30% tax ruling'],
          desvantagens: ['Salário mínimo alto', 'Restrito a empresas reconhecidas']
        },
        startupVisa: {
          nome: 'Startup Visa',
          tipo: 'Empreendedorismo',
          descricao: 'Visto para empreendedores com ideia inovadora.',
          requisitos: ['Produto/serviço inovador', 'Facilitador aprovado', 'Recursos financeiros', 'Plano de negócios'],
          timeline: '1-3 meses',
          custoEstimado: '€1.000-5.000',
          taxaSucesso: '70%',
          vantagens: ['Acesso ao ecossistema de startups', 'Pode evoluir para self-employed'],
          desvantagens: ['Precisa facilitador', 'Válido apenas 1 ano inicialmente']
        }
      },
      cidades: ['Amsterdã', 'Rotterdam', 'Haia', 'Utrecht', 'Eindhoven', 'Groningen']
    },
    canada: {
      nome: 'Canadá',
      bandeira: '🇨🇦',
      capital: 'Ottawa',
      idioma: 'Inglês/Francês',
      custoVida: 'Alto',
      qualidadeVida: '9/10',
      seguranca: '9/10',
      clima: 'Frio',
      comunidadeBR: 'Grande (100k+)',
      tempoResidencia: '3 anos para cidadania',
      rotas: {
        expressEntry: {
          nome: 'Express Entry',
          tipo: 'Sistema de pontos',
          descricao: 'Sistema de pontos para imigração qualificada.',
          requisitos: ['Pontuação CRS competitiva (470+)', 'Teste de idioma (IELTS/CELPIP)', 'Avaliação de credenciais (ECA)', 'Experiência de trabalho qualificado'],
          timeline: '6-12 meses',
          custoEstimado: 'CAD$2.500-5.000',
          taxaSucesso: '80%',
          vantagens: ['Residência permanente direta', 'Processo transparente', 'Pode levar família'],
          desvantagens: ['Alta competição', 'Pontuação muda frequentemente']
        },
        pnp: {
          nome: 'Provincial Nominee Program',
          tipo: 'Nomeação provincial',
          descricao: 'Programas provinciais para residência permanente.',
          requisitos: ['Variam por província', 'Experiência na área demandada', 'Conexão com a província', 'Intenção de residir na província'],
          timeline: '12-18 meses',
          custoEstimado: 'CAD$2.000-5.000',
          taxaSucesso: '75%',
          vantagens: ['+600 pontos no Express Entry', 'Opções para diferentes perfis'],
          desvantagens: ['Compromisso com província', 'Processos variam muito']
        }
      },
      cidades: ['Toronto', 'Vancouver', 'Montreal', 'Calgary', 'Ottawa', 'Edmonton']
    }
  };

  const sections = [
    { title: 'Dados Pessoais', icon: User, color: 'blue' },
    { title: 'Perfil Profissional', icon: Briefcase, color: 'green' },
    { title: 'Realizações', icon: Star, color: 'yellow' },
    { title: 'Formação Acadêmica', icon: GraduationCap, color: 'purple' },
    { title: 'Situação Empresarial', icon: Building2, color: 'orange' },
    { title: 'Idiomas', icon: Languages, color: 'cyan' },
    { title: 'Capacidade Financeira', icon: DollarSign, color: 'emerald' },
    { title: 'Composição Familiar', icon: Users, color: 'pink' },
    { title: 'Objetivos de Vida', icon: Target, color: 'red' },
    { title: 'Preferências de Destino', icon: MapPin, color: 'indigo' },
    { title: 'Timeline', icon: Clock, color: 'slate' }
  ];

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleMultiSelect = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(v => v !== value)
        : [...prev[field], value]
    }));
  };

  const nextSection = () => {
    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
      window.scrollTo(0, 0);
    } else {
      handleSubmitAndAnalyze();
    }
  };

  const prevSection = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1);
      window.scrollTo(0, 0);
    }
  };

  // Função de cálculo de score
  const calculateDetailedScore = () => {
    let scores = {
      portugal: { total: 0, viabilidade: 0, alinhamento: 0, timeline: 0, custoBeneficio: 0, potencial: 0, rotas: {} },
      alemanha: { total: 0, viabilidade: 0, alinhamento: 0, timeline: 0, custoBeneficio: 0, potencial: 0, rotas: {} },
      eua: { total: 0, viabilidade: 0, alinhamento: 0, timeline: 0, custoBeneficio: 0, potencial: 0, rotas: {} },
      espanha: { total: 0, viabilidade: 0, alinhamento: 0, timeline: 0, custoBeneficio: 0, potencial: 0, rotas: {} },
      holanda: { total: 0, viabilidade: 0, alinhamento: 0, timeline: 0, custoBeneficio: 0, potencial: 0, rotas: {} },
      canada: { total: 0, viabilidade: 0, alinhamento: 0, timeline: 0, custoBeneficio: 0, potencial: 0, rotas: {} }
    };

    // VIABILIDADE
    if (formData.areaAtuacao === 'tech') {
      scores.portugal.viabilidade += 35; scores.alemanha.viabilidade += 35;
      scores.holanda.viabilidade += 35; scores.eua.viabilidade += 30;
      scores.canada.viabilidade += 30; scores.espanha.viabilidade += 25;
      scores.portugal.rotas.techVisa = 95; scores.portugal.rotas.d8 = 85;
      scores.alemanha.rotas.blueCard = 90; scores.holanda.rotas.kennismigrant = 90;
    }
    
    const expMap = { '0-2': 5, '3-5': 15, '6-8': 25, '9-12': 35, '13-15': 40, '16-20': 45, '20+': 50 };
    const expScore = expMap[formData.anosExperiencia] || 0;
    Object.keys(scores).forEach(country => { scores[country].viabilidade += expScore * 0.5; });
    
    if (['13-15', '16-20', '20+'].includes(formData.anosExperiencia)) {
      scores.eua.viabilidade += 15;
      scores.eua.rotas.eb2Niw = (scores.eua.rotas.eb2Niw || 50) + 20;
    }

    if (formData.nivelFormacao === 'mestrado') {
      scores.eua.viabilidade += 20; scores.alemanha.viabilidade += 15;
      scores.canada.viabilidade += 20; scores.eua.rotas.eb2Niw = (scores.eua.rotas.eb2Niw || 50) + 25;
    }
    if (['doutorado', 'posDoutorado'].includes(formData.nivelFormacao)) {
      scores.eua.viabilidade += 30; scores.alemanha.viabilidade += 25;
      scores.canada.viabilidade += 30; scores.eua.rotas.eb1a = (scores.eua.rotas.eb1a || 30) + 30;
    }

    if (formData.possuiPremios !== 'nao' && formData.possuiPremios) {
      scores.eua.viabilidade += 20; scores.eua.rotas.eb1a = (scores.eua.rotas.eb1a || 30) + 20;
      scores.eua.rotas.o1a = (scores.eua.rotas.o1a || 40) + 20;
    }
    if (formData.possuiPublicacoes !== 'nao' && formData.possuiPublicacoes) {
      scores.eua.viabilidade += 15; scores.eua.rotas.eb2Niw = (scores.eua.rotas.eb2Niw || 50) + 10;
    }

    if (['fluente', 'nativo'].includes(formData.nivelIngles)) {
      scores.eua.viabilidade += 25; scores.canada.viabilidade += 30;
      scores.holanda.viabilidade += 20; scores.alemanha.viabilidade += 15;
    }
    if (['fluente', 'avancado'].includes(formData.nivelEspanhol)) {
      scores.espanha.viabilidade += 30; scores.espanha.rotas.nomadaDigital = 90;
    }
    if (['fluente', 'avancado'].includes(formData.nivelAlemao)) {
      scores.alemanha.viabilidade += 25;
    }

    if (['1m-2m', '2m-5m', 'acima5m'].includes(formData.patrimonioLiquido)) {
      scores.portugal.rotas.goldenVisa = 95; scores.eua.rotas.eb5 = 90;
    }
    if (['interesse', 'prioridade'].includes(formData.disposicaoGoldenVisa)) {
      scores.portugal.viabilidade += 20; scores.espanha.viabilidade += 15;
    }

    if (formData.possuiEmpresa && !['nao', 'encerrada'].includes(formData.possuiEmpresa)) {
      scores.holanda.rotas.startupVisa = 80; scores.canada.rotas.startupVisa = 75;
      if (['filial', 'exporta'].includes(formData.atuacaoInternacional)) {
        scores.eua.rotas.l1a = 85; scores.eua.viabilidade += 20;
      }
    }

    // ALINHAMENTO
    if (formData.paisesInteresse.includes('portugal')) scores.portugal.alinhamento += 40;
    if (formData.paisesInteresse.includes('alemanha')) scores.alemanha.alinhamento += 40;
    if (formData.paisesInteresse.includes('espanha')) scores.espanha.alinhamento += 40;
    if (formData.paisesInteresse.includes('holanda')) scores.holanda.alinhamento += 40;
    if (formData.paisesInteresse.includes('eua')) scores.eua.alinhamento += 40;
    if (formData.paisesInteresse.includes('canada')) scores.canada.alinhamento += 40;

    if (['mediterraneo', 'tropical'].includes(formData.preferenciaClima)) {
      scores.portugal.alinhamento += 25; scores.espanha.alinhamento += 25;
    }
    if (['temperado', 'frio'].includes(formData.preferenciaClima)) {
      scores.alemanha.alinhamento += 20; scores.canada.alinhamento += 20;
    }

    if (formData.preferenciaIdiomaPais === 'portugues') scores.portugal.alinhamento += 30;
    if (formData.preferenciaIdiomaPais === 'espanhol') scores.espanha.alinhamento += 30;
    if (formData.preferenciaIdiomaPais === 'ingles') {
      scores.eua.alinhamento += 25; scores.canada.alinhamento += 25;
    }

    if (formData.importanciaComunidadeBR === 'essencial') {
      scores.portugal.alinhamento += 25; scores.eua.alinhamento += 20;
    }

    if (formData.numeroFilhos && formData.numeroFilhos !== '0') {
      scores.portugal.alinhamento += 15; scores.espanha.alinhamento += 15; scores.canada.alinhamento += 20;
    }

    // TIMELINE
    if (['imediato', '6meses'].includes(formData.prazoIdeal)) {
      scores.portugal.timeline += 40; scores.alemanha.timeline += 35;
      scores.holanda.timeline += 45; scores.espanha.timeline += 35;
      scores.eua.timeline += 15; scores.canada.timeline += 20;
    }
    if (['2anos', '3anos'].includes(formData.prazoIdeal)) {
      scores.eua.timeline += 35; scores.canada.timeline += 40;
    }

    // CUSTO-BENEFÍCIO
    if (['ate20k', '20k-50k'].includes(formData.capacidadeInvestimento)) {
      scores.portugal.custoBeneficio += 35; scores.alemanha.custoBeneficio += 40;
      scores.espanha.custoBeneficio += 35;
    }
    if (['500k-1m', 'acima1m'].includes(formData.capacidadeInvestimento)) {
      scores.portugal.custoBeneficio += 40; scores.eua.custoBeneficio += 40;
    }

    // POTENCIAL LP
    scores.espanha.potencial += 40; // 2 anos para BR
    scores.canada.potencial += 35; // 3 anos
    scores.portugal.potencial += 30;
    scores.eua.potencial += 30;

    if (formData.possuiDuplaCidadania && !['nao'].includes(formData.possuiDuplaCidadania)) {
      if (['italiana', 'portuguesa', 'alema', 'espanhola', 'outraUE'].includes(formData.possuiDuplaCidadania)) {
        scores.portugal.potencial += 50; scores.alemanha.potencial += 50;
        scores.espanha.potencial += 50; scores.holanda.potencial += 50;
      }
    }

    // Calcular totais
    Object.keys(scores).forEach(country => {
      const s = scores[country];
      s.total = Math.round(
        (s.viabilidade * 0.35) + (s.alinhamento * 0.25) +
        (s.timeline * 0.15) + (s.custoBeneficio * 0.15) + (s.potencial * 0.10)
      );
      s.total = Math.min(s.total, 100);
      Object.keys(s.rotas).forEach(rota => { s.rotas[rota] = Math.min(s.rotas[rota], 100); });
    });

    return scores;
  };

  const getBestRoutes = (countryKey, scores) => {
    const routes = scores[countryKey].rotas;
    const countryRoutes = countryData[countryKey]?.rotas || {};
    return Object.entries(routes)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([key, score]) => ({ key, score, ...countryRoutes[key] }))
      .filter(r => r.nome);
  };

  // Submeter dados e mostrar análise
  const handleSubmitAndAnalyze = async () => {
    setIsSubmitting(true);
    
    const scores = calculateDetailedScore();
    const topCountries = Object.entries(scores)
      .sort((a, b) => b[1].total - a[1].total)
      .slice(0, 5)
      .map(([key, data]) => ({ 
        key, 
        name: countryData[key]?.nome,
        score: data.total,
        ...data, 
        info: countryData[key] 
      }));
    
    const bestRoutes = getBestRoutes(topCountries[0].key, scores);
    
    const analysisResults = {
      topCountries,
      recommendedRoute: bestRoutes[0]?.nome || 'Consultar especialista',
      scores
    };

    // Enviar dados para email e sheets
    try {
      const results = await submitQuestionnaireData(formData, analysisResults);
      setSubmissionStatus(results);
    } catch (error) {
      console.error('Erro ao enviar dados:', error);
      setSubmissionStatus({ email: { success: false }, sheets: { success: false } });
    }

    setIsSubmitting(false);
    setShowAnalysis(true);
  };

  const renderRadio = (label, field, options, required = false, columns = 1) => (
    <div className="mb-5">
      <label className="block text-sm font-medium text-gray-700 mb-3">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <div className={`grid gap-2 ${columns === 2 ? 'grid-cols-1 sm:grid-cols-2' : columns === 3 ? 'grid-cols-1 sm:grid-cols-3' : 'grid-cols-1'}`}>
        {options.map(opt => (
          <label key={opt.value} className={`flex items-center p-3 border rounded-lg cursor-pointer transition-all ${
            formData[field] === opt.value ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 hover:border-gray-300'
          }`}>
            <input type="radio" name={field} value={opt.value} checked={formData[field] === opt.value}
              onChange={(e) => handleChange(field, e.target.value)} className="sr-only" />
            <div className={`w-4 h-4 rounded-full border-2 mr-3 flex items-center justify-center ${
              formData[field] === opt.value ? 'border-blue-500' : 'border-gray-300'
            }`}>
              {formData[field] === opt.value && <div className="w-2 h-2 rounded-full bg-blue-500" />}
            </div>
            <span className="text-sm">{opt.label}</span>
          </label>
        ))}
      </div>
    </div>
  );

  const renderCheckbox = (label, field, options, columns = 2) => (
    <div className="mb-5">
      <label className="block text-sm font-medium text-gray-700 mb-3">{label}</label>
      <div className={`grid gap-2 ${columns === 2 ? 'grid-cols-1 sm:grid-cols-2' : columns === 3 ? 'grid-cols-1 sm:grid-cols-3' : 'grid-cols-1'}`}>
        {options.map(opt => (
          <label key={opt.value} className={`flex items-center p-3 border rounded-lg cursor-pointer transition-all ${
            formData[field].includes(opt.value) ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 hover:border-gray-300'
          }`}>
            <input type="checkbox" checked={formData[field].includes(opt.value)}
              onChange={() => handleMultiSelect(field, opt.value)} className="sr-only" />
            <div className={`w-5 h-5 rounded border-2 mr-3 flex items-center justify-center ${
              formData[field].includes(opt.value) ? 'border-blue-500 bg-blue-500' : 'border-gray-300'
            }`}>
              {formData[field].includes(opt.value) && <Check className="w-3 h-3 text-white" />}
            </div>
            <span className="text-sm">{opt.label}</span>
          </label>
        ))}
      </div>
    </div>
  );

  const renderInput = (label, field, placeholder = '', required = false) => (
    <div className="mb-5">
      <label className="block text-sm font-medium text-gray-700 mb-2">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input type="text" value={formData[field]} onChange={(e) => handleChange(field, e.target.value)}
        placeholder={placeholder} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
    </div>
  );

  const renderSection = () => {
    switch (currentSection) {
      case 0:
        return (
          <div className="space-y-6">
            {renderInput('Nome Completo', 'nomeCompleto', 'Seu nome completo', true)}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {renderInput('E-mail', 'email', 'seu@email.com', true)}
              {renderInput('Telefone/WhatsApp', 'telefone', '+55 11 99999-9999', true)}
            </div>
            {renderRadio('Faixa Etária', 'faixaEtaria', [
              { value: '18-25', label: '18 a 25 anos' }, { value: '26-30', label: '26 a 30 anos' },
              { value: '31-35', label: '31 a 35 anos' }, { value: '36-40', label: '36 a 40 anos' },
              { value: '41-45', label: '41 a 45 anos' }, { value: '46-50', label: '46 a 50 anos' },
              { value: '51-55', label: '51 a 55 anos' }, { value: '56+', label: '56 anos ou mais' }
            ], true, 2)}
            {renderRadio('Estado Civil', 'estadoCivil', [
              { value: 'solteiro', label: 'Solteiro(a)' }, { value: 'casado', label: 'Casado(a)' },
              { value: 'uniao', label: 'União Estável' }, { value: 'divorciado', label: 'Divorciado(a)' }
            ], true, 2)}
            {renderRadio('Possui dupla cidadania?', 'possuiDuplaCidadania', [
              { value: 'nao', label: 'Não' }, { value: 'italiana', label: 'Italiana' },
              { value: 'portuguesa', label: 'Portuguesa' }, { value: 'alema', label: 'Alemã' },
              { value: 'espanhola', label: 'Espanhola' }, { value: 'outraUE', label: 'Outra UE' },
              { value: 'emProcesso', label: 'Em processo' }
            ], false, 2)}
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            {renderRadio('Área de Atuação', 'areaAtuacao', [
              { value: 'tech', label: '💻 Tecnologia / TI' }, { value: 'saude', label: '🏥 Saúde' },
              { value: 'engenharia', label: '⚙️ Engenharia' }, { value: 'financas', label: '💰 Finanças' },
              { value: 'marketing', label: '📢 Marketing' }, { value: 'juridico', label: '⚖️ Jurídico' },
              { value: 'educacao', label: '📚 Educação' }, { value: 'negocios', label: '📊 Negócios' },
              { value: 'outro', label: 'Outro' }
            ], true, 2)}
            {renderRadio('Nível do Cargo', 'nivelCargo', [
              { value: 'junior', label: 'Júnior' }, { value: 'pleno', label: 'Pleno' },
              { value: 'senior', label: 'Sênior' }, { value: 'lead', label: 'Tech Lead' },
              { value: 'gerente', label: 'Gerente' }, { value: 'diretor', label: 'Diretor' },
              { value: 'cLevel', label: 'C-Level' }, { value: 'empresario', label: 'Empresário' }
            ], true, 2)}
            {renderRadio('Anos de Experiência', 'anosExperiencia', [
              { value: '0-2', label: '0 a 2 anos' }, { value: '3-5', label: '3 a 5 anos' },
              { value: '6-8', label: '6 a 8 anos' }, { value: '9-12', label: '9 a 12 anos' },
              { value: '13-15', label: '13 a 15 anos' }, { value: '16-20', label: '16 a 20 anos' },
              { value: '20+', label: 'Mais de 20 anos' }
            ], true, 2)}
            {renderRadio('Gestão de equipes', 'gestaoEquipe', [
              { value: 'nao', label: 'Não' }, { value: 'pequena', label: '1-5 pessoas' },
              { value: 'media', label: '6-15 pessoas' }, { value: 'grande', label: '16-50 pessoas' },
              { value: 'multiplas', label: '50+ pessoas' }
            ], true, 2)}
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <p className="text-sm text-blue-800"><AlertCircle className="inline w-4 h-4 mr-1" />
                Crucial para vistos O-1A, EB-1A e Global Talent.</p>
            </div>
            {renderRadio('Prêmios profissionais?', 'possuiPremios', [
              { value: 'nao', label: 'Não' }, { value: '1-2', label: '1 a 2' },
              { value: '3-5', label: '3 a 5' }, { value: '6+', label: '6 ou mais' }
            ], true, 2)}
            {renderRadio('Publicações?', 'possuiPublicacoes', [
              { value: 'nao', label: 'Não' }, { value: '1-3', label: '1 a 3' },
              { value: '4-10', label: '4 a 10' }, { value: '10+', label: 'Mais de 10' }
            ], true, 2)}
            {renderRadio('Patentes?', 'possuiPatentes', [
              { value: 'nao', label: 'Não' }, { value: '1', label: '1' },
              { value: '2-3', label: '2 a 3' }, { value: '4+', label: '4+' }
            ], true, 2)}
            {renderRadio('Palestras?', 'possuiPalestras', [
              { value: 'nao', label: 'Não' }, { value: '1-5', label: '1 a 5' },
              { value: '6-15', label: '6 a 15' }, { value: '15+', label: '15+' }
            ], true, 2)}
            {renderRadio('Mídia?', 'aparicoesMidia', [
              { value: 'nao', label: 'Nenhuma' }, { value: 'poucas', label: '1 a 3' },
              { value: 'varias', label: '4 a 10' }, { value: 'muitas', label: '10+' }
            ], true, 2)}
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            {renderRadio('Maior Formação', 'nivelFormacao', [
              { value: 'medio', label: 'Ensino Médio' }, { value: 'tecnico', label: 'Técnico' },
              { value: 'graduacao', label: 'Graduação' }, { value: 'posGraduacao', label: 'Pós/MBA' },
              { value: 'mestrado', label: 'Mestrado' }, { value: 'doutorado', label: 'Doutorado' },
              { value: 'posDoutorado', label: 'Pós-Doutorado' }
            ], true)}
            {renderRadio('Área do Curso', 'areaCurso', [
              { value: 'exatas', label: 'Exatas (Eng, Comp, Mat)' },
              { value: 'biologicas', label: 'Biológicas (Med, Bio)' },
              { value: 'humanas', label: 'Humanas (Dir, Psi, Adm)' },
              { value: 'negocios', label: 'Negócios e Gestão' },
              { value: 'outro', label: 'Outro' }
            ], true, 2)}
            {renderCheckbox('Certificações', 'certificacoes', [
              { value: 'aws', label: 'AWS' }, { value: 'gcp', label: 'Google Cloud' },
              { value: 'azure', label: 'Azure' }, { value: 'pmp', label: 'PMP' },
              { value: 'scrum', label: 'Scrum' }, { value: 'idioma', label: 'Idioma' },
              { value: 'nenhuma', label: 'Nenhuma' }
            ], 2)}
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            {renderRadio('Possui empresa?', 'possuiEmpresa', [
              { value: 'nao', label: 'Não' }, { value: 'mei', label: 'MEI' },
              { value: 'me', label: 'ME/EPP' }, { value: 'ltda', label: 'LTDA' },
              { value: 'socio', label: 'Sócio minoritário' }
            ], true, 2)}
            {formData.possuiEmpresa && !['nao'].includes(formData.possuiEmpresa) && (
              <>
                {renderRadio('Faturamento Anual', 'faturamentoAnual', [
                  { value: 'ate81k', label: 'Até R$81k' }, { value: '81k-360k', label: 'R$81k-360k' },
                  { value: '360k-1m', label: 'R$360k-1M' }, { value: '1m-5m', label: 'R$1M-5M' },
                  { value: 'acima5m', label: 'Acima R$5M' }
                ], false, 2)}
                {renderRadio('Atuação Internacional', 'atuacaoInternacional', [
                  { value: 'nao', label: 'Não' }, { value: 'exporta', label: 'Exporta' },
                  { value: 'clientes', label: 'Clientes no exterior' }, { value: 'filial', label: 'Filial no exterior' }
                ], false, 2)}
              </>
            )}
            {renderRadio('Interesse em empreender no exterior?', 'interesseEmpreenderExterior', [
              { value: 'nao', label: 'Não' }, { value: 'talvez', label: 'Talvez' },
              { value: 'sim', label: 'Sim' }, { value: 'jaTenho', label: 'Já tenho' }
            ], true, 2)}
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            {renderRadio('Nível de Inglês', 'nivelIngles', [
              { value: 'nenhum', label: 'Não falo' }, { value: 'basico', label: 'Básico' },
              { value: 'intermediario', label: 'Intermediário' }, { value: 'avancado', label: 'Avançado' },
              { value: 'fluente', label: 'Fluente' }, { value: 'nativo', label: 'Nativo' }
            ], true)}
            {renderRadio('Nível de Espanhol', 'nivelEspanhol', [
              { value: 'nenhum', label: 'Não falo' }, { value: 'basico', label: 'Básico' },
              { value: 'intermediario', label: 'Intermediário' }, { value: 'avancado', label: 'Avançado' },
              { value: 'fluente', label: 'Fluente' }
            ], false, 3)}
            {renderRadio('Nível de Alemão', 'nivelAlemao', [
              { value: 'nenhum', label: 'Não falo' }, { value: 'basico', label: 'Básico' },
              { value: 'intermediario', label: 'Intermediário' }, { value: 'avancado', label: 'Avançado' },
              { value: 'fluente', label: 'Fluente' }
            ], false, 3)}
            {renderRadio('Disposição para aprender?', 'disposicaoAprender', [
              { value: 'nao', label: 'Prefiro país onde já falo' },
              { value: 'basico', label: 'Aprenderia o básico' },
              { value: 'sim', label: 'Sim, disposto' }
            ], true)}
          </div>
        );

      case 6:
        return (
          <div className="space-y-6">
            {renderRadio('Renda Mensal Familiar', 'rendaMensalFamiliar', [
              { value: 'ate5k', label: 'Até R$5k' }, { value: '5k-10k', label: 'R$5k-10k' },
              { value: '10k-20k', label: 'R$10k-20k' }, { value: '20k-35k', label: 'R$20k-35k' },
              { value: '35k-50k', label: 'R$35k-50k' }, { value: '50k-80k', label: 'R$50k-80k' },
              { value: 'acima80k', label: 'Acima R$80k' }
            ], true, 2)}
            {renderRadio('Patrimônio Líquido', 'patrimonioLiquido', [
              { value: 'ate50k', label: 'Até R$50k' }, { value: '50k-100k', label: 'R$50k-100k' },
              { value: '100k-250k', label: 'R$100k-250k' }, { value: '250k-500k', label: 'R$250k-500k' },
              { value: '500k-1m', label: 'R$500k-1M' }, { value: '1m-2m', label: 'R$1M-2M' },
              { value: 'acima2m', label: 'Acima R$2M' }
            ], true, 2)}
            {renderRadio('Investimento no processo', 'capacidadeInvestimento', [
              { value: 'ate20k', label: 'Até R$20k' }, { value: '20k-50k', label: 'R$20k-50k' },
              { value: '50k-100k', label: 'R$50k-100k' }, { value: '100k-200k', label: 'R$100k-200k' },
              { value: '200k-500k', label: 'R$200k-500k' }, { value: '500k-1m', label: 'R$500k-1M' },
              { value: 'acima1m', label: 'Acima R$1M' }
            ], true, 2)}
            {renderRadio('Interesse em Golden Visa/EB-5?', 'disposicaoGoldenVisa', [
              { value: 'nao', label: 'Não' }, { value: 'considero', label: 'Consideraria' },
              { value: 'interesse', label: 'Tenho interesse' }, { value: 'prioridade', label: 'Prioridade' }
            ], true, 2)}
          </div>
        );

      case 7:
        return (
          <div className="space-y-6">
            {(formData.estadoCivil === 'casado' || formData.estadoCivil === 'uniao') && (
              <>
                {renderRadio('Área do Cônjuge', 'areaConjuge', [
                  { value: 'tech', label: 'Tecnologia' }, { value: 'saude', label: 'Saúde' },
                  { value: 'educacao', label: 'Educação' }, { value: 'outro', label: 'Outro' },
                  { value: 'na', label: 'Não trabalha' }
                ], false, 3)}
                {renderRadio('Flexibilidade do Cônjuge', 'flexibilidadeConjuge', [
                  { value: 'total', label: 'Total' }, { value: 'parcial', label: 'Parcial' },
                  { value: 'resistente', label: 'Resistente' }
                ], true, 3)}
              </>
            )}
            {renderRadio('Número de Filhos', 'numeroFilhos', [
              { value: '0', label: 'Nenhum' }, { value: '1', label: '1' },
              { value: '2', label: '2' }, { value: '3', label: '3' }, { value: '4+', label: '4+' }
            ], true, 3)}
            {formData.numeroFilhos && formData.numeroFilhos !== '0' && (
              renderCheckbox('Faixa Etária dos Filhos', 'faixaEtariaFilhos', [
                { value: 'bebe', label: '0-2 anos' }, { value: 'preEscola', label: '3-5 anos' },
                { value: 'fundamental1', label: '6-10 anos' }, { value: 'fundamental2', label: '11-14 anos' },
                { value: 'medio', label: '15-17 anos' }, { value: 'adulto', label: '18+' }
              ], 2)
            )}
          </div>
        );

      case 8:
        return (
          <div className="space-y-6">
            {renderCheckbox('Motivações (até 5)', 'motivacaoPrincipal', [
              { value: 'seguranca', label: '🛡️ Segurança' }, { value: 'qualidadeVida', label: '🌟 Qualidade de vida' },
              { value: 'carreira', label: '📈 Crescimento profissional' }, { value: 'salario', label: '💰 Aumento de renda' },
              { value: 'educacaoFilhos', label: '🎓 Educação dos filhos' }, { value: 'saude', label: '🏥 Saúde' },
              { value: 'estabilidade', label: '🏛️ Estabilidade' }, { value: 'cidadania', label: '🇪🇺 Cidadania UE' },
              { value: 'empreender', label: '🚀 Empreender' }, { value: 'aventura', label: '✈️ Nova experiência' }
            ], 2)}
            {renderRadio('Objetivo de Carreira', 'objetivoCarreira', [
              { value: 'mesmaArea', label: 'Continuar na área' }, { value: 'crescer', label: 'Crescer' },
              { value: 'mudarArea', label: 'Mudar área' }, { value: 'empreender', label: 'Empreender' },
              { value: 'equilibrio', label: 'Mais equilíbrio' }
            ], true)}
            {renderRadio('Expectativa Salarial', 'expectativaSalarial', [
              { value: 'menor', label: 'Aceito ganhar menos' }, { value: 'igual', label: 'Manter' },
              { value: 'maior', label: 'Ganhar mais' }, { value: 'muitoMaior', label: 'Dobrar' }
            ], true, 2)}
            {renderRadio('Plano de Retorno', 'planoRetorno', [
              { value: 'nunca', label: 'Não pretendo voltar' }, { value: 'aposentadoria', label: 'Na aposentadoria' },
              { value: 'temporario', label: 'Alguns anos' }, { value: 'incerto', label: 'Não sei' }
            ], true, 2)}
          </div>
        );

      case 9:
        return (
          <div className="space-y-6">
            {renderCheckbox('Países de Interesse', 'paisesInteresse', [
              { value: 'portugal', label: '🇵🇹 Portugal' }, { value: 'espanha', label: '🇪🇸 Espanha' },
              { value: 'alemanha', label: '🇩🇪 Alemanha' }, { value: 'holanda', label: '🇳🇱 Holanda' },
              { value: 'eua', label: '🇺🇸 Estados Unidos' }, { value: 'canada', label: '🇨🇦 Canadá' },
              { value: 'irlanda', label: '🇮🇪 Irlanda' }, { value: 'uk', label: '🇬🇧 Reino Unido' },
              { value: 'aberto', label: '🌍 Aberto a sugestões' }
            ], 3)}
            {renderRadio('Preferência de Clima', 'preferenciaClima', [
              { value: 'tropical', label: '☀️ Quente' }, { value: 'mediterraneo', label: '🌅 Mediterrâneo' },
              { value: 'temperado', label: '🍂 Temperado' }, { value: 'frio', label: '❄️ Frio OK' },
              { value: 'indiferente', label: 'Indiferente' }
            ], true, 3)}
            {renderRadio('Comunidade Brasileira', 'importanciaComunidadeBR', [
              { value: 'essencial', label: 'Essencial' }, { value: 'importante', label: 'Importante' },
              { value: 'indiferente', label: 'Indiferente' }, { value: 'evitar', label: 'Prefiro evitar' }
            ], true, 2)}
            {renderRadio('Preferência de Idioma', 'preferenciaIdiomaPais', [
              { value: 'portugues', label: 'Lusófono' }, { value: 'espanhol', label: 'Hispânico' },
              { value: 'ingles', label: 'Anglófono' }, { value: 'aprender', label: 'Disposto aprender' },
              { value: 'indiferente', label: 'Indiferente' }
            ], true, 3)}
            {renderRadio('Custo de Vida', 'toleranciaCustoVida', [
              { value: 'baixo', label: 'Prefiro baixo' }, { value: 'medio', label: 'Médio OK' },
              { value: 'alto', label: 'Alto OK' }
            ], true, 3)}
          </div>
        );

      case 10:
        return (
          <div className="space-y-6">
            {renderRadio('Prazo para Mudança', 'prazoIdeal', [
              { value: 'imediato', label: 'Imediato (3 meses)' }, { value: '6meses', label: 'Até 6 meses' },
              { value: '1ano', label: '6m a 1 ano' }, { value: '2anos', label: '1 a 2 anos' },
              { value: '3anos', label: '2 a 3 anos' }, { value: 'semPressa', label: 'Sem pressa' }
            ], true, 2)}
            {renderRadio('Flexibilidade', 'flexibilidadePrazo', [
              { value: 'rigido', label: 'Rígido' }, { value: 'flexivel', label: 'Flexível' },
              { value: 'muitoFlexivel', label: 'Muito flexível' }
            ], true, 3)}
            {renderRadio('Situação no Brasil', 'situacaoAtualBrasil', [
              { value: 'estavel', label: 'Estável' }, { value: 'estavelInsatisfeito', label: 'Estável mas insatisfeito' },
              { value: 'transicao', label: 'Em transição' }, { value: 'urgente', label: 'Urgente' }
            ], true, 2)}
            {renderRadio('Já iniciou processo?', 'jaIniciouProcesso', [
              { value: 'nao', label: 'Não' }, { value: 'pesquisando', label: 'Pesquisando' },
              { value: 'documentos', label: 'Reunindo docs' }, { value: 'processoAtivo', label: 'Processo ativo' }
            ], true, 2)}
            {renderRadio('Conhecimento sobre Rotas', 'conhecimentoRotas', [
              { value: 'nenhum', label: 'Nenhum' }, { value: 'basico', label: 'Básico' },
              { value: 'moderado', label: 'Moderado' }, { value: 'avancado', label: 'Avançado' }
            ], true, 2)}
          </div>
        );

      default:
        return null;
    }
  };

  // RENDER ANÁLISE
  const renderAnalysis = () => {
    const scores = calculateDetailedScore();
    const topCountries = Object.entries(scores)
      .sort((a, b) => b[1].total - a[1].total)
      .slice(0, 5)
      .map(([key, data]) => ({ key, ...data, info: countryData[key] }));
    
    const topCountry = topCountries[0];
    const bestRoutes = getBestRoutes(topCountry.key, scores);

    return (
      <div className="space-y-6">
        {/* Header com status de envio */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Check className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-gray-800">Relatório Geofitting</h2>
          <p className="text-gray-600 mt-2">Análise completa para {formData.nomeCompleto || 'Cliente'}</p>
          
          {/* Status de envio */}
          {submissionStatus && (
            <div className="flex justify-center gap-4 mt-4">
              <div className={`flex items-center px-3 py-1 rounded-full text-sm ${
                submissionStatus.email?.success ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
              }`}>
                <Mail className="w-4 h-4 mr-1" />
                {submissionStatus.email?.success ? 'Email enviado' : 'Email pendente'}
              </div>
              <div className={`flex items-center px-3 py-1 rounded-full text-sm ${
                submissionStatus.sheets?.success ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
              }`}>
                <Database className="w-4 h-4 mr-1" />
                {submissionStatus.sheets?.success ? 'Dados salvos' : 'Dados pendentes'}
              </div>
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 justify-center bg-gray-100 p-2 rounded-xl">
          {[
            { id: 'resumo', label: 'Resumo', icon: FileText },
            { id: 'destinos', label: 'Destinos', icon: MapPin },
            { id: 'rotas', label: 'Rotas', icon: Plane },
            { id: 'comparativo', label: 'Comparativo', icon: TrendingUp }
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id ? 'bg-white text-blue-600 shadow-md' : 'text-gray-600 hover:text-gray-800'
              }`}>
              <tab.icon className="w-4 h-4 mr-2" />{tab.label}
            </button>
          ))}
        </div>

        {/* Tab Resumo */}
        {activeTab === 'resumo' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-xl p-6 text-white">
              <h3 className="text-xl font-bold mb-4">Sumário Executivo</h3>
              <p className="text-blue-100 leading-relaxed">
                Com base na análise do seu perfil, identificamos <strong>{topCountry.info?.nome}</strong> como 
                seu destino mais compatível, com score de <strong>{topCountry.total}%</strong>. 
                A rota recomendada é <strong>{bestRoutes[0]?.nome || 'Tech Visa'}</strong>, 
                com timeline estimada de <strong>{bestRoutes[0]?.timeline || '3-6 meses'}</strong>.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white rounded-xl p-4 shadow-md border-l-4 border-blue-500">
                <p className="text-xs text-gray-500">Área</p>
                <p className="font-bold capitalize">{formData.areaAtuacao || 'N/A'}</p>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-md border-l-4 border-green-500">
                <p className="text-xs text-gray-500">Experiência</p>
                <p className="font-bold">{formData.anosExperiencia || 'N/A'}</p>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-md border-l-4 border-purple-500">
                <p className="text-xs text-gray-500">Formação</p>
                <p className="font-bold capitalize">{formData.nivelFormacao || 'N/A'}</p>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-md border-l-4 border-orange-500">
                <p className="text-xs text-gray-500">Timeline</p>
                <p className="font-bold">{formData.prazoIdeal || 'N/A'}</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab Destinos */}
        {activeTab === 'destinos' && (
          <div className="space-y-4">
            {topCountries.map((country, index) => (
              <div key={country.key} className={`bg-white rounded-xl shadow-lg overflow-hidden ${index === 0 ? 'ring-2 ring-green-500' : ''}`}>
                <div className="p-4 cursor-pointer" onClick={() => setExpandedCountry(expandedCountry === index ? null : index)}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <span className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${
                        index === 0 ? 'bg-green-500' : index === 1 ? 'bg-blue-500' : 'bg-gray-400'
                      }`}>{index + 1}</span>
                      <span className="text-3xl ml-3">{country.info?.bandeira}</span>
                      <div className="ml-3">
                        <h4 className="font-bold text-lg">{country.info?.nome}</h4>
                        <p className="text-sm text-gray-500">{country.info?.capital}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold">{country.total}%</div>
                      <div className="text-xs text-gray-500">Compatibilidade</div>
                    </div>
                  </div>
                  <div className="mt-3 h-2 bg-gray-200 rounded-full">
                    <div className={`h-full rounded-full ${index === 0 ? 'bg-green-500' : 'bg-blue-500'}`}
                      style={{ width: `${country.total}%` }} />
                  </div>
                </div>
                {expandedCountry === index && (
                  <div className="border-t p-4 bg-gray-50">
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p><span className="text-gray-500">Custo de Vida:</span> {country.info?.custoVida}</p>
                        <p><span className="text-gray-500">Segurança:</span> {country.info?.seguranca}</p>
                        <p><span className="text-gray-500">Comunidade BR:</span> {country.info?.comunidadeBR}</p>
                      </div>
                      <div>
                        <p><span className="text-gray-500">Clima:</span> {country.info?.clima}</p>
                        <p><span className="text-gray-500">Cidadania:</span> {country.info?.tempoResidencia}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Tab Rotas */}
        {activeTab === 'rotas' && (
          <div className="space-y-6">
            {topCountries.slice(0, 3).map((country) => {
              const routes = getBestRoutes(country.key, scores);
              return (
                <div key={country.key} className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="bg-gray-800 p-4 text-white flex items-center">
                    <span className="text-2xl mr-2">{country.info?.bandeira}</span>
                    <h4 className="font-bold">{country.info?.nome}</h4>
                    <span className="ml-auto bg-white/20 px-3 py-1 rounded-full text-sm">{country.total}%</span>
                  </div>
                  <div className="p-4 space-y-3">
                    {routes.length > 0 ? routes.map((route, idx) => (
                      <div key={route.key} className="border rounded-lg overflow-hidden">
                        <div className="p-4 cursor-pointer hover:bg-gray-50"
                          onClick={() => setExpandedRoute(expandedRoute === `${country.key}-${route.key}` ? null : `${country.key}-${route.key}`)}>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <span className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                                idx === 0 ? 'bg-green-500' : 'bg-gray-400'
                              }`}>{idx + 1}</span>
                              <div className="ml-3">
                                <h5 className="font-semibold">{route.nome}</h5>
                                <p className="text-xs text-gray-500">{route.tipo}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-bold">{route.score}%</div>
                              <div className="text-xs text-gray-500">{route.timeline}</div>
                            </div>
                          </div>
                        </div>
                        {expandedRoute === `${country.key}-${route.key}` && (
                          <div className="border-t p-4 bg-gray-50">
                            <p className="text-gray-600 mb-4">{route.descricao}</p>
                            <div className="grid md:grid-cols-2 gap-4">
                              <div>
                                <h6 className="font-medium mb-2">Requisitos</h6>
                                <ul className="text-sm space-y-1">
                                  {route.requisitos?.map((req, i) => (
                                    <li key={i} className="flex items-start">
                                      <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0 mt-0.5" />{req}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                              <div>
                                <p className="text-sm"><strong>Custo:</strong> {route.custoEstimado}</p>
                                <p className="text-sm"><strong>Taxa de Sucesso:</strong> {route.taxaSucesso}</p>
                                <div className="mt-2 grid grid-cols-2 gap-2">
                                  <div className="bg-green-50 p-2 rounded text-xs">
                                    <strong className="text-green-800">Vantagens:</strong>
                                    <ul className="text-green-700 mt-1">
                                      {route.vantagens?.slice(0, 2).map((v, i) => <li key={i}>• {v}</li>)}
                                    </ul>
                                  </div>
                                  <div className="bg-red-50 p-2 rounded text-xs">
                                    <strong className="text-red-800">Desvantagens:</strong>
                                    <ul className="text-red-700 mt-1">
                                      {route.desvantagens?.slice(0, 2).map((d, i) => <li key={i}>• {d}</li>)}
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )) : <p className="text-gray-500 text-center py-4">Consulte um especialista.</p>}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Tab Comparativo */}
        {activeTab === 'comparativo' && (
          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-xl shadow-lg overflow-hidden">
              <thead>
                <tr className="bg-gray-800 text-white">
                  <th className="p-4 text-left">Critério</th>
                  {topCountries.slice(0, 4).map((c) => (
                    <th key={c.key} className="p-4 text-center">
                      <span className="text-2xl block">{c.info?.bandeira}</span>
                      {c.info?.nome}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y">
                {[
                  { label: 'Score Total', key: 'total', suffix: '%' },
                  { label: 'Viabilidade', key: 'viabilidade' },
                  { label: 'Alinhamento', key: 'alinhamento' },
                  { label: 'Timeline', key: 'timeline' }
                ].map((row, i) => (
                  <tr key={row.key} className={i % 2 === 0 ? 'bg-gray-50' : ''}>
                    <td className="p-4 font-medium">{row.label}</td>
                    {topCountries.slice(0, 4).map((c) => (
                      <td key={c.key} className="p-4 text-center font-bold">
                        {Math.round(c[row.key])}{row.suffix || ''}
                      </td>
                    ))}
                  </tr>
                ))}
                <tr>
                  <td className="p-4 font-medium">Cidadania</td>
                  {topCountries.slice(0, 4).map((c) => (
                    <td key={c.key} className="p-4 text-center text-sm">{c.info?.tempoResidencia}</td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}

        {/* CTA */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-xl p-6 text-white">
          <h3 className="text-xl font-bold mb-4">Próximos Passos</h3>
          <p className="text-blue-100 mb-6">
            Este é um diagnóstico preliminar. Para uma análise completa com advogados especializados, 
            agende uma consulta com nossa equipe.
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <a href={`https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '5511999999999'}?text=Olá! Acabei de preencher o Geofitting e gostaria de agendar uma consulta. Meu nome é ${formData.nomeCompleto}`}
              target="_blank" rel="noopener noreferrer"
              className="flex-1 bg-green-500 text-white font-semibold py-3 px-6 rounded-lg hover:bg-green-600 transition-colors flex items-center justify-center">
              <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              Falar no WhatsApp
            </a>
            <button className="flex-1 bg-white text-blue-700 font-semibold py-3 px-6 rounded-lg hover:bg-blue-50 transition-colors flex items-center justify-center">
              <Calendar className="w-5 h-5 mr-2" />
              Agendar Consulta
            </button>
          </div>
        </div>

        <div className="text-center">
          <button onClick={() => { setShowAnalysis(false); setCurrentSection(0); setActiveTab('resumo'); }}
            className="text-blue-600 hover:text-blue-800 font-medium">
            ← Voltar e editar respostas
          </button>
        </div>
      </div>
    );
  };

  // Loading durante submissão
  if (isSubmitting) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-16 h-16 text-blue-600 animate-spin mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Analisando seu perfil...</h2>
          <p className="text-gray-600">Estamos processando suas respostas</p>
        </div>
      </div>
    );
  }

  // Render principal
  if (showAnalysis) {
    return (
      <>
        <Head>
          <title>Seu Relatório Geofitting | UK Consultoria Migratória</title>
          <meta name="description" content="Relatório personalizado de análise migratória" />
        </Head>
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-8 px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-6">
              <h1 className="text-2xl font-bold text-gray-800">GEOFITTING</h1>
              <p className="text-sm text-gray-500">UK Consultoria Migratória</p>
            </div>
            {renderAnalysis()}
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Head>
        <title>Geofitting | Seu Mapa Migratório | UK Consultoria</title>
        <meta name="description" content="Descubra o melhor destino e rota migratória para seu perfil" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-800">GEOFITTING</h1>
            <p className="text-gray-600">Seu Mapa Migratório Personalizado</p>
            <p className="text-sm text-gray-500 mt-2">UK Consultoria Migratória</p>
          </div>

          <div className="mb-8">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Seção {currentSection + 1} de {sections.length}</span>
              <span>{Math.round(((currentSection + 1) / sections.length) * 100)}% completo</span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div className="h-full bg-blue-600 transition-all duration-300"
                style={{ width: `${((currentSection + 1) / sections.length) * 100}%` }} />
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-6 justify-center">
            {sections.map((section, index) => {
              const Icon = section.icon;
              return (
                <button key={index} onClick={() => setCurrentSection(index)}
                  className={`flex items-center px-3 py-1.5 rounded-full text-xs transition-all ${
                    index === currentSection ? 'bg-blue-600 text-white'
                      : index < currentSection ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                  }`}>
                  <Icon className="w-3 h-3 mr-1" />
                  <span className="hidden md:inline">{section.title}</span>
                  <span className="md:hidden">{index + 1}</span>
                </button>
              );
            })}
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
            <div className="flex items-center mb-6">
              {React.createElement(sections[currentSection].icon, { className: "w-6 h-6 text-blue-600 mr-3" })}
              <h2 className="text-xl font-semibold text-gray-800">{sections[currentSection].title}</h2>
            </div>

            {renderSection()}

            <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
              <button onClick={prevSection} disabled={currentSection === 0}
                className={`flex items-center px-6 py-2 rounded-lg transition-colors ${
                  currentSection === 0 ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}>
                <ChevronLeft className="w-5 h-5 mr-1" />Anterior
              </button>
              <button onClick={nextSection}
                className="flex items-center px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                {currentSection === sections.length - 1 ? (
                  <><CheckCircle2 className="w-5 h-5 mr-1" />Gerar Análise</>
                ) : (
                  <>Próximo<ChevronRight className="w-5 h-5 ml-1" /></>
                )}
              </button>
            </div>
          </div>

          <div className="text-center mt-8 text-sm text-gray-500">
            <p>Suas informações são confidenciais e protegidas.</p>
            <p className="mt-1">© 2026 UK Consultoria Migratória</p>
          </div>
        </div>
      </div>
    </>
  );
}
